var group__MS__COM__SERIAL__IF =
[
    [ "SF_STACK_RX_EVENT_LEN", "group__MS__COM__SERIAL__IF.html#ga96c8d58c81d511792891da455ad86a60", null ],
    [ "sf_stack_serial_init", "group__MS__COM__SERIAL__IF.html#gab3dfa86dfbeaeaf53cc1a1f66d8c723f", null ],
    [ "sf_stack_serial_run", "group__MS__COM__SERIAL__IF.html#gabc1563119121be0e3472ea526eef7e7f", null ],
    [ "sf_stack_hal_serial_isBusy", "group__MS__COM__SERIAL__IF.html#gadc645f962d7bdd6973d3497f7d2b1d3e", null ],
    [ "sf_stack_serial_isIdle", "group__MS__COM__SERIAL__IF.html#ga1672962b2e53d95ea0a49e59ece7f0e2", null ],
    [ "sf_stack_serial_action", "group__MS__COM__SERIAL__IF.html#gacfb929eba09853024e0e7a0f7f11333e", null ],
    [ "sf_stack_serial_indication", "group__MS__COM__SERIAL__IF.html#ga4b5864702b43f1b43eecfb8d3395ecfa", null ],
    [ "sf_stack_serial_setKey", "group__MS__COM__SERIAL__IF.html#ga17c0336cee7311b52d02325de073ef08", null ],
    [ "sf_stack_serial_getKey", "group__MS__COM__SERIAL__IF.html#gac8d865ebdb6f8f2c19b7fb772315afa9", null ],
    [ "sf_stack_serial_changeSecurity", "group__MS__COM__SERIAL__IF.html#gacdb6bb81807b6d9a64ded374d3b5a7bd", null ]
];