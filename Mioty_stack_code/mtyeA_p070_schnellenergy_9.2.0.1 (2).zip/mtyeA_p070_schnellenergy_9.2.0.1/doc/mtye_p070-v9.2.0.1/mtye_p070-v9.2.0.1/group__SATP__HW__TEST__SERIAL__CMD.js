var group__SATP__HW__TEST__SERIAL__CMD =
[
    [ "Serial HW test common information", "group__SATP__SERIAL__HW__TEST__COMMON__TEXT.html", null ],
    [ "Serial HW test common Example", "group__SATP__SERIAL__HW__TEST__COMMON__EXAMPLE.html", null ],
    [ "SATP_HW_TEST_API_ID_CMD", "group__SATP__HW__TEST__SERIAL__CMD.html#ga86d6c3b07d31a1bb152ba03d17e3c77b", null ],
    [ "SATP_HW_TEST_START_TX_CW", "group__SATP__HW__TEST__SERIAL__CMD.html#ga146377cb1d34e50a968d1590e18394c3", null ],
    [ "SATP_HW_TEST_START_TX_MOD_CW", "group__SATP__HW__TEST__SERIAL__CMD.html#gaa58a99037d77d2dc0158f9817e61bb13", null ],
    [ "SATP_HW_TEST_START_RX", "group__SATP__HW__TEST__SERIAL__CMD.html#ga7017435d29339642e752a9b2f5a54e45", null ],
    [ "SATP_HW_TEST_STOP", "group__SATP__HW__TEST__SERIAL__CMD.html#gaea8b214b21fbddc601040a10eac95a10", null ],
    [ "SATP_HW_TEST_START_TX", "group__SATP__HW__TEST__SERIAL__CMD.html#ga2841fc70ee37e688d8096558ba7afd56", null ]
];