var group__MS__COM__IF__EX =
[
    [ "stackState_t", "group__MS__COM__IF__EX.html#gaff7d900454f65d4685a52d689dd12c23", [
      [ "E_STACK_STATE_IDLE", "group__MS__COM__IF__EX.html#ggaff7d900454f65d4685a52d689dd12c23a04083cb9e6edd51cb1d6a8c14fe3cd08", null ],
      [ "E_STACK_STATE_BUSY_PROCESS", "group__MS__COM__IF__EX.html#ggaff7d900454f65d4685a52d689dd12c23acd9ef4fad8fac22425c0482b96b0b714", null ],
      [ "E_STACK_STATE_BUSY_SLEEP", "group__MS__COM__IF__EX.html#ggaff7d900454f65d4685a52d689dd12c23abf8938346fbdef1ba70598fc79fd6ccb", null ],
      [ "E_STACK_STATE_BUSY_DEEP_SLEEP", "group__MS__COM__IF__EX.html#ggaff7d900454f65d4685a52d689dd12c23ac99118f44b8c30450aa7e8e803ead449", null ]
    ] ],
    [ "sf_stack_nb_send", "group__MS__COM__IF__EX.html#ga645f3712ab92e700a9f0b63bea58af17", null ],
    [ "sf_stack_nb_process", "group__MS__COM__IF__EX.html#ga3cad4171907d53f9fd6583c2a53fe501", null ],
    [ "sf_stack_nb_isBusy", "group__MS__COM__IF__EX.html#ga0ad6ad0d1191336ca790d6bc62684cea", null ]
];