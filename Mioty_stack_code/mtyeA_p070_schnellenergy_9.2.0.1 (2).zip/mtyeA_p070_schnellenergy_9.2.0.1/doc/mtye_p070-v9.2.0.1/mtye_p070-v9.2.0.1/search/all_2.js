var searchData=
[
  ['guides_0',['Guides',['../STACK_GUIDES.html',1,'']]]
];
