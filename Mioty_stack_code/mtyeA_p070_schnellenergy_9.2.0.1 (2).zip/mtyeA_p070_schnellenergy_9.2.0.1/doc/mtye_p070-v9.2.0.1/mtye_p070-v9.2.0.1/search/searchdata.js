var indexSectionsWithContent =
{
  0: "aeghilprst",
  1: "s",
  2: "s",
  3: "hs",
  4: "es",
  5: "ahrs",
  6: "agilprst"
};

var indexSectionNames =
{
  0: "all",
  1: "functions",
  2: "typedefs",
  3: "enums",
  4: "enumvalues",
  5: "groups",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Functions",
  2: "Typedefs",
  3: "Enumerations",
  4: "Enumerator",
  5: "Modules",
  6: "Pages"
};

