var searchData=
[
  ['prepare_20the_20ide_0',['Prepare the IDE',['../STACK_PREPARE_IDE.html',1,'STACK_GUIDES']]]
];
