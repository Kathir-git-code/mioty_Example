var examples =
[
    [ "exampleMain.c", "exampleMain_8c-example.html", null ],
    [ "modemMain.c", "modemMain_8c-example.html", null ],
    [ "exampleMainHwTest.c", "exampleMainHwTest_8c-example.html", null ]
];