var STACK_GUIDES =
[
    [ "Stack Porting Guide", "STACK_PORTING_GUIDE.html", [
      [ "Overview", "STACK_PORTING_GUIDE.html#autotoc_md26", null ],
      [ "Recommended Procedure", "STACK_PORTING_GUIDE.html#autotoc_md27", null ]
    ] ],
    [ "Stack Usage", "STACK_HOW_TO.html", [
      [ "Serial Application", "STACK_HOW_TO.html#autotoc_md28", null ],
      [ "API Application", "STACK_HOW_TO.html#autotoc_md29", null ]
    ] ],
    [ "Prepare the IDE", "STACK_PREPARE_IDE.html", [
      [ "IDE List", "STACK_PREPARE_IDE.html#IDE_LIST", null ],
      [ "Setting up Code Composer Studio IDE", "STACK_PREPARE_IDE.html#SETUP_CCS", null ]
    ] ],
    [ "Troubleshooting", "TROUBLESHOOTING.html", [
      [ "File path length and CMake", "TROUBLESHOOTING.html#autotoc_md17", [
        [ "Description", "TROUBLESHOOTING.html#autotoc_md18", null ],
        [ "Solution", "TROUBLESHOOTING.html#autotoc_md19", null ]
      ] ],
      [ "Unable to determine what CMake generator to use<", "TROUBLESHOOTING.html#autotoc_md20", [
        [ "Description", "TROUBLESHOOTING.html#autotoc_md21", null ],
        [ "Solution", "TROUBLESHOOTING.html#autotoc_md22", null ]
      ] ],
      [ "OpenOCD starts and exits with code 1", "TROUBLESHOOTING.html#autotoc_md23", [
        [ "Description", "TROUBLESHOOTING.html#autotoc_md24", null ],
        [ "Solution", "TROUBLESHOOTING.html#autotoc_md25", null ]
      ] ]
    ] ]
];