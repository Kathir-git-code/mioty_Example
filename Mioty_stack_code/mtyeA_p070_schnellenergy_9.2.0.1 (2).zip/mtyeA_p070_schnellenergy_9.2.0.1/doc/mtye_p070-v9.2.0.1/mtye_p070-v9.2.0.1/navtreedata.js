/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "mioty Endpoint Device", "index.html", [
    [ "Introduction", "index.html", [
      [ "Overview", "index.html#autotoc_md0", null ],
      [ "Contents", "index.html#autotoc_md1", null ],
      [ "Contact Information", "index.html#autotoc_md2", null ]
    ] ],
    [ "API Overview", "STACK_API.html", "STACK_API" ],
    [ "Guides", "STACK_GUIDES.html", "STACK_GUIDES" ],
    [ "Radio Test", "PAGE_HW_TEST_COM_IF.html", [
      [ "Introduction", "PAGE_HW_TEST_COM_IF.html#autotoc_md30", null ],
      [ "Radio test API", "PAGE_HW_TEST_COM_IF.html#autotoc_md31", null ],
      [ "Radio test modem API", "PAGE_HW_TEST_COM_IF.html#autotoc_md32", null ]
    ] ],
    [ "Stack Serial Interface", "STACK_SERIAL_INTERFACE.html", [
      [ "About the Serial Interface", "STACK_SERIAL_INTERFACE.html#autotoc_md33", [
        [ "Overview", "STACK_SERIAL_INTERFACE.html#autotoc_md34", null ],
        [ "Serial MAC Frame", "STACK_SERIAL_INTERFACE.html#autotoc_md35", null ],
        [ "SATP for Stack", "STACK_SERIAL_INTERFACE.html#autotoc_md36", null ]
      ] ],
      [ "Serial Command Set", "STACK_SERIAL_INTERFACE.html#autotoc_md37", [
        [ "Ping", "STACK_SERIAL_INTERFACE.html#autotoc_md38", null ],
        [ "Stack Common", "STACK_SERIAL_INTERFACE.html#autotoc_md39", null ]
      ] ]
    ] ],
    [ "Supported Devices", "STACK_SUPPORTED_DEVICES.html", [
      [ "Supported Devices List", "STACK_SUPPORTED_DEVICES.html#DEVICES_LIST", null ],
      [ "Required software tools", "STACK_SUPPORTED_DEVICES.html#SW_DEPENDENCIES", null ],
      [ "CC1352R1 Launchpad", "STACK_SUPPORTED_DEVICES.html#CC1352R1_LAUNCHPAD", [
        [ "Description of the hardware interface", "STACK_SUPPORTED_DEVICES.html#DESC", [
          [ "Used Pins", "STACK_SUPPORTED_DEVICES.html#USED_PINS", null ],
          [ "Supported transmission powers", "STACK_SUPPORTED_DEVICES.html#TX_POWER", null ]
        ] ]
      ] ],
      [ "Secure Serial Communication", "STACK_SUPPORTED_DEVICES.html#SECURE_SERIAL", [
        [ "About Secure Serial Communication", "STACK_SUPPORTED_DEVICES.html#ABOUT_SECURE_SERIAL", [
          [ "Known limitations", "STACK_SUPPORTED_DEVICES.html#KNOWN_LIMITATIONS", null ],
          [ "Power consumption", "STACK_SUPPORTED_DEVICES.html#POWER_CONSUMPTION", null ]
        ] ]
      ] ]
    ] ],
    [ "License Information", "LICENSE_INFORMATION.html", [
      [ "License Information for Software/IP by STACKFORCE", "LICENSE_INFORMATION.html#autotoc_md45", null ]
    ] ],
    [ "Modules", "modules.html", "modules" ],
    [ "Examples", "examples.html", "examples" ]
  ] ]
];

var NAVTREEINDEX =
[
"LICENSE_INFORMATION.html",
"group__SF__HW__TEST__IF.html#gaec8f2d211f6d7b6a230b595fa6d519f4"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';