var group__SF__HW__TEST__IF =
[
    [ "HW test common information", "group__SF__HW__TEST__COMMON__TEXT.html", null ],
    [ "hwTestReturn_t", "group__SF__HW__TEST__IF.html#gade0bbd2a6c1cc4004bee624a04ea5561", [
      [ "E_HW_TEST_RETURN_SUCCESS", "group__SF__HW__TEST__IF.html#ggade0bbd2a6c1cc4004bee624a04ea5561aa86160f47b1c5c0b226b208e23f9c959", null ],
      [ "E_HW_TEST_RETURN_ERROR", "group__SF__HW__TEST__IF.html#ggade0bbd2a6c1cc4004bee624a04ea5561aa33b1b0549ea9d7d930a5e38aebe21da", null ],
      [ "E_HW_TEST_RETURN_ERROR_INVALID_PARAM", "group__SF__HW__TEST__IF.html#ggade0bbd2a6c1cc4004bee624a04ea5561a9e6d6a13b633135c333ee0e6fb436dc7", null ],
      [ "E_HW_TEST_RETURN_ERROR_MODE_NOT_SUPPORTED", "group__SF__HW__TEST__IF.html#ggade0bbd2a6c1cc4004bee624a04ea5561a7915ff688645f7d55af4665e8450508a", null ]
    ] ],
    [ "hwTestMode_t", "group__SF__HW__TEST__IF.html#gad4409bdb46cc308bb3e227f24e52281c", [
      [ "E_HW_TEST_MODE_WMBUS_S", "group__SF__HW__TEST__IF.html#ggad4409bdb46cc308bb3e227f24e52281ca2d91aa5f83f116e4806f0fb5b70f7548", null ],
      [ "E_HW_TEST_MODE_WMBUS_M2O_T", "group__SF__HW__TEST__IF.html#ggad4409bdb46cc308bb3e227f24e52281cafe67fe41e7b77dc780a27ecb23478a4e", null ],
      [ "E_HW_TEST_MODE_WMBUS_M2O_C", "group__SF__HW__TEST__IF.html#ggad4409bdb46cc308bb3e227f24e52281ca205e3c6bd43fbbd543ff9256c9727b55", null ],
      [ "E_HW_TEST_MODE_LORAWAN_FSK", "group__SF__HW__TEST__IF.html#ggad4409bdb46cc308bb3e227f24e52281cadad56896f2475760b9342bbe81697b1c", null ],
      [ "E_HW_TEST_MODE_MIOTY", "group__SF__HW__TEST__IF.html#ggad4409bdb46cc308bb3e227f24e52281ca2f6ef1b4deee7735acd3fb8a153ca43f", null ]
    ] ],
    [ "sf_hw_test_startTx", "group__SF__HW__TEST__IF.html#gaec8f2d211f6d7b6a230b595fa6d519f4", null ],
    [ "sf_hw_test_startTxCw", "group__SF__HW__TEST__IF.html#ga76df14907f964c602f744f82a588f277", null ],
    [ "sf_hw_test_startTxModCw", "group__SF__HW__TEST__IF.html#ga5d3c6b2bb7d6ad9b41eba286f744f74a", null ],
    [ "sf_hw_test_startRx", "group__SF__HW__TEST__IF.html#ga04ce6b4cd5e9b5f4dfeabae2928df593", null ],
    [ "sf_hw_test_stop", "group__SF__HW__TEST__IF.html#gadc5d5549a8e615adc95136678107358b", null ]
];