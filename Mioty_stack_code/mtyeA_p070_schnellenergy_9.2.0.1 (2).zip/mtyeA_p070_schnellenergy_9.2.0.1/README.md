# Readme

This is the STACKFORCE example package which combines the STACKFORCE mioty Stack and the STACKFORCE TI CC13x2 platform.

Package version: v9.2.0.1

## Introduction

You have received a protocol stack delivery package from STACKFORCE. With this Readme document, we give you a brief overview of how you can find and use information within the delivery package. Before working with the stack, please read the license information "LICENSE.md".

**Documentation paths:**

- API and source code documentation: doc/doxygen/*.html ***(Please open the documentation with your web browser and make sure you unpack the .zip file.)***

  - Guides:
    - Prepare the IDE: User guide how you can setup your IDE.
    - Stack Usage: Generic guide about how to use the stack.
  - Stack Serial Interface: Documentation about our serial protocol if you use the exampleMainSerial application.
    - Supported Devices: Configuration options of the supported device(s)

- Application notes: doc/ANxxxx.pdf
- Changelog.md: Depicts the technical changes from version to version.

## Getting started

- To get started, please set up your environment first. Our **"Doxygen: Prepare the IDE"** guide will help you to set up the IDE and all build tools.
- Afterwards you should be able to run our example application on the supported hardware.
- If you need more information how to use our stack library please see the **"Doxygen: Stack usage"** guide.
- If you would like to use our stack as a modem version, please refer to the **"Doxygen: Stack Serial Interface"** guide. STACKFORCE provides a (Windows/Linux) PC tool for serial communication with the modem application of the device. Please contact sales@stackforce.de
- If you need more detailed information about using the stack, please refer to the stack API documentation **"Doxygen: API overview"**.

## Technical remarks
