
# STACKFORCE Stack Changelog for CC13x2

## 9.2.0.1

### Changelog

- Add EUI address limitation for a specific customer.
- No functional change.

### Known issues

- We could reach the target of ~1uA power consumption on the CC13x2 launchpad.
  However the power consumption raises to ~2uA in IDLE mode after performing a transmission.

## 9.2.0.0

### Changelog

- Added India profile IN866

### Known issues

- We could reach the target of ~1uA power consumption on the CC13x2 launchpad.
  However the power consumption raises to ~2uA in IDLE mode after performing a transmission.

## 9.1.2.0

### Changelog

- HW-Tests: Added missing define of SF_HW_TEST_FREQ_IN_HZ to use an supported mioty frequency
- Extended device specific documentation.
  - Added the supported tx-power steps in to the "Supported Device" section of the doxygen documentation
- Updated location where the persistent data will be stored.
  - Updated the macros `SECTOR_SIZE` and `SECTOR_TO_USE`

### Known issues

- We could reach the target of ~1uA power consumption on the CC13x2 launchpad.
  However the power consumption raises to ~2uA in IDLE mode after performing a transmission.

## 9.1.2.0-rc.1

### Changelog

- Updated timing parameters for tx-prepare to 3ms to ensure enough time even if the device is in a deeper sleep mode
- Improve stability of the rx and tx-logic

### Known issues

- We could reach the target of ~1uA power consumption on the CC13x2 launchpad.
  However the power consumption raises to ~2uA in IDLE mode after performing a transmission.

## 9.1.1.0

### Changelog

- Updated names of hex files. Now the *.out and *.hex file will use the same names
- Updated ccs project names in order to allow the include of multiple ccs projects in one workspace.
  - If several projects should be part of one workspace, only one 'tirtos_builds_CC13x2_cc26x2_release_ccs' project needs to be added!
- Set the referenced Build-configuration to 'Debug' for the referenced project `tirtos_builds_CC13x2_cc26x2_release_ccs`
- Added support of hardware tests
- Add AN1012_mioty_rf_tests.pdf
- Add AN1004_user_specific_serial_cmds.pdf
- Refactored the project structure
- Rework mioty hal and disclose HAL dependencies
- Add support of none-blocking transmission
- Reduced required RAM for mtyeZ configs

### Known issues

- We could reach the target of ~1uA power consumption on the CC13x2 launchpad.
  However the power consumption raises to ~2uA in IDLE mode after performing a transmission.

## previous versions

- Version numbers 5 till 8 are skipped for this product.


## 4.5.0

- Added NVM support for CC13x0
- Removed the possibility to get the mioty network key
- Updated the CC13xx to the new HAL version
  - CC13x0: version 1.1.2
  - CC13x2: version 1.0.2
- Updated the mioty ep core to version 2.4.0-2

## 4.4.0

- Added new mioty parameters
  - E_STACK_PARAM_ID_MIOTY_ACK_REQUEST (Used to request an ack of an UL transmission. For bidirectional devices only.)
  - E_STACK_PARAM_ID_MIOTY_RX_WINDOW (Used to enable/disable the rx window after an uplink transmission. For bidirectional devices only.)
- Reduce footprint by disabling Assertion-Strings

## 4.3.1

- Enabled optimization for CC13x0/CC13x2 ccs lib build configs

## 4.3.0

- Update CC13x0 ccs configs
- Apply changes described in v4.2.0 to the CC13x0 devices
- Fix CC13x0 UL transmission issue
- Add low power optimization for modem configurations

## 4.2.0

- Add possibility to set the Mioty tx power
- Increase default tx-power to 14 dBm
- Add possibility to set the mioty short address
- Fixed wrong length reported inside rx-event
- Update CCS to v10.2.0.00009

### 4.1.0

- Add API function to get active stack

### 4.0.0

- Updates modem firmware application.
- Fix data length handling of an RX success event (Lib).
- Update documentation of Modem configuration.

### 3.1.0

- Add low power feature for CC13xx.
- Update the CC13xx to the new HAL version.

### 3.0.0

- Refactor Receive functionality (API change).
- Wrong reference documentation of E_STACK_EVENT_TYPE_RX_INDICATION.
- Refactor exampleMain application.

### 2.0.0

- Add low power feature (API change).
- Rename API functions, variables and files.

### 1.1.0

- Add feature to support mioty MPF field.
- Enable bidirectional Mioty communication.

### 1.0.0

- Initial Release.

## CC13x0 Target

### 1.2.0

- Updates the HAL to use the RTC instead of an general timer.

### 1.1.1

- Fix re-initialisation of CC13x0 HAL

### 1.1.0

- Updates EU2 and US0 carrier settings.
- Use updated radio overrides for CC13x0 devices.

### 1.0.0

- Initial Release.
