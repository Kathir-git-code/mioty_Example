#ifdef __cplusplus
extern "C" {
#endif

/**
 @code
  ___ _____ _   ___ _  _____ ___  ___  ___ ___
 / __|_   _/_\ / __| |/ / __/ _ \| _ \/ __| __|
 \__ \ | |/ _ \ (__| ' <| _| (_) |   / (__| _|
 |___/ |_/_/ \_\___|_|\_\_| \___/|_|_\\___|___|
 embedded.connectivity.solutions.==============
 @endcode

 @file
 @copyright  STACKFORCE GmbH, Germany, www.stackforce.de
 @author     STACKFORCE
 @brief      Example main application for the Stack API.

 @example    exampleMain.c
             Example for the API usage of the stack.
*/
/* Standard libraries */
#include <stdint.h>
#include <stdbool.h>

#include "exampleMain.h"
#include "sf_app_hal_lp.h"
#include "sf_app_hal_system.h"
#include "sf_app_hal.h"
#include "sf_app_hal_timer.h"
#include "sf_stack.h"
#include "sf_stack_nb.h"
#include "sf_stack_app_ex.h"
#include "sf_memory_management.h"

#ifndef SF_STACK_NUMBER
/*! The definitions SF_STACK_NUMBER is available in the CMakeLists.txt */
#define SF_STACK_NUMBER                 0
#endif

#ifndef SF_STACK_LIST
/*! The definitions SF_STACK_LIST is available in the CMakeLists.txt */
#define SF_STACK_LIST                   { E_STACK_ID_NONE }
#endif

#ifndef SF_STACK_NB_ENABLED
/*! The definition SF_STACK_NB_ENABLED is by default set to 0.
    It defines, if a telegram should be send in a blocking or non blocking way. */
#define SF_STACK_NB_ENABLED             0
#endif

/*! Flag that indicates, that a transmission is ready */
static volatile bool gReadyToSend;
/*! Variable that holds the rx length */
static volatile uint16_t gRxDataLength;
/*! Flag that indicates, that the stack data has changed. */
static volatile bool gStackDataChanged = false;

/*============================================================================*/
/*!
 * @brief  Callback function definition of the stack. This function will be
 *         passed to the stack initialization function as parameter. The stack
 *         uses this callback to inform the application layer about event.
 *
 * @param  event    Defines the event which occurred.
 * @param  data     A pointer to data. The pointer can be NULL, as not
 *                  every event requires data.
 * @param  dataLen  The length of the data. Can be zero.
 *
 * @return The return value shall be E_STACK_RETURN_SUCCESS.
 */
/*============================================================================*/
static stackReturn_t loc_callback( stackEvent_t event, uint8_t *data,
                                   uint16_t dataLen )
{
  /* Handle the events triggered by the Stack */
  switch( event )
  {
    case E_STACK_EVENT_SLEEP:
      /* Application sleep function without RAM loss. */
      sf_app_hal_lp_enterSleep( );
      break;

    case E_STACK_EVENT_DEEP_SLEEP:
      /* Application deep sleep function without RAM loss. */
      sf_app_hal_lp_enterDeepSleep( );
      break;

    case E_STACK_EVENT_WAKEUP:
      /* Application wakeup function. */
      sf_app_hal_lp_wakeup();
      break;

    case E_STACK_EVENT_RX_SUCCESS:
      /* Indication about a new received message. */
      if( sizeof(gRxDataLength) == dataLen )
      {
        gRxDataLength = (data[1] | data[0] << 8);
      }
      break;

    case E_STACK_EVENT_PERSISTENT_DATA_UPDATE:
      /* Indication about updated nvm context. */
      gStackDataChanged = true;
      break;

    default:
      break;
  }

  return E_STACK_RETURN_SUCCESS;
}

/*============================================================================*/
/*!
 * @brief  Callback function definition of the timer. This callback function
 *         sets a status to initiate another transmission.
 *
 * @param  pCtx    A pointer to a potential data context.
 */
/*============================================================================*/
static void loc_timerCallback( void* pCtx )
{
  sf_app_hal_lp_wakeup();
  gReadyToSend = true;
}

/*============================================================================*/
/*!
 * @brief  Function to transmit and receive data.
 */
/*============================================================================*/
static void loc_sendData( void )
{
  uint8_t sampleData[] = { 0x01, 0x02, 0x03, 0x04, 0x05 };
  stackReturn_t status = E_STACK_RETURN_ERROR;

  #if ( 0 == SF_STACK_NB_ENABLED )
  /* Send a frame in a blocking way. */
  status = sf_stack_send( sizeof(sampleData), sampleData );
  #elif ( 1 == SF_STACK_NB_ENABLED )
  /* Send a frame in a non blocking way. */
  status = sf_stack_nb_send( sizeof(sampleData), sampleData );
  #endif

  /* Error Handling. */
  if( status == E_STACK_RETURN_ERROR )
  {
    /* Please note that if you use evaluation version the allowed
        number of transmissions and payload size is limited.
        Check the main page of the Documentation for more information.  */
    sf_app_hal_system_errorHandler( );
  }
}

/*============================================================================*/
/*!
 * @brief  Gets the next stack
 *
 * @return The next stack @ref stackId_t
 */
/*============================================================================*/
static stackId_t loc_getNextStack( void )
{
  static uint8_t currentIndex = 0;
  uint8_t stacks[] = SF_STACK_LIST;
  stackId_t ret = E_STACK_ID_NONE;

  ret = (stackId_t) stacks[currentIndex];

  currentIndex++;

  if( currentIndex >= SF_STACK_NUMBER )
  {
    currentIndex = 0;
  }
  return ret;
}

/*============================================================================*/
/*!
 * @brief  Handles multiprotocol transmissions.
 */
/*============================================================================*/
static void loc_handleTransmission(void)
{
  stackId_t currentStack = E_STACK_ID_NONE;

  /* Check if the timer has expired. */
  if( true == gReadyToSend )
  {
    /* Reset flag. */
    gReadyToSend = false;

    /* Choose the stack for the upcoming transmission */
    currentStack = loc_getNextStack( );

    /* Select the stack and enable it */
    if( E_STACK_RETURN_SUCCESS == sf_stack_selectStack( currentStack ) )
    {
      /* Transmit a frame. */
      loc_sendData( );
    }

    /* Start a timer */
    if( true != sf_app_hal_timer_start( 30U, loc_timerCallback ) )
    {
      sf_app_hal_system_errorHandler( );
    }
  }
}

/*============================================================================*/
/*!
 * @brief  Handles the low power mode and process function.
 */
/*============================================================================*/
static void loc_handleStackStates( void )
{
  uint8_t rxData[255] = { 0x00 };
  stackState_t stackState = sf_stack_nb_isBusy();

  if( stackState == E_STACK_STATE_IDLE )
  {
    /* Receive data, if available */
    if( gRxDataLength > 0 )
    {
      sf_stack_receive( gRxDataLength, rxData );
      gRxDataLength = 0;
    }

    /* Write stack data to NVM, if available.
       Please note that the NVM write cycles are limited.
       Please take care about the function sf_stack_app_mem_ex_writeNvm( ). */
    if( true == gStackDataChanged )
    {
      sf_memory_management_writeNvm( );
      gStackDataChanged = false;
    }
  }

  if((E_STACK_STATE_BUSY_SLEEP == stackState) && (gReadyToSend == false))
  {
    sf_app_hal_lp_enterSleep( );
  }
  else if((stackState != E_STACK_STATE_BUSY_PROCESS) && (gReadyToSend == false))
  {
    sf_app_hal_lp_enterDeepSleep( );
  }
  sf_stack_nb_process( );
}

/*============================================================================*/
/*!
 * @brief  Main loop function.
 *         It initializes the stack and transmits a frame continuously.
 */
/*============================================================================*/
void exampleMain( void )
{
  gReadyToSend = true;
  gRxDataLength = 0;
  uint8_t stacks[] = SF_STACK_LIST;

  sf_app_hal_init( );
  sf_memory_management_init( );

  /* Initialize the stack API */
  if( E_STACK_RETURN_SUCCESS != sf_stack_init( loc_callback ) )
  {
    sf_app_hal_system_errorHandler( );
  }

  /* Initialize application extensions, if possible */
  if( E_STACK_RETURN_SUCCESS != sf_app_ex_init( ) )
  {
    sf_app_hal_system_errorHandler( );
  }

  /* Initializes the stacks with NVM data, if possible. */
  sf_memory_management_readNvm( SF_STACK_NUMBER, stacks );

  while( 1 )
  {
    /* Handles multiprotocol transmissions */
    loc_handleTransmission( );

    /* Handles the stack states. */
    loc_handleStackStates( );
  }
}

/*============================================================================*/
/*!
 * @brief  Main function.
 */
/*============================================================================*/
#ifndef SF_USE_RTOS_APPLICATION
int main( void )
{
  exampleMain( );
  return 0;
}
#endif /* SF_USE_RTOS_APPLICATION */

#ifdef __cplusplus
}
#endif
