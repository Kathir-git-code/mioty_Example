# License Information

## License Information for Software/IP by STACKFORCE

When reading this license information you propably have been receiving software and/or IP that has been created and is owned by STACKFORCE.

All rights are owned by STACKFORCE and any usage, including and especially commercial usage, must be according to the appropriate license agreement between you and STACKFORCE.

If you don't have such an agreement, if you're not sure if you have one, if you're not sure about the details of an existing agreement or in any other case of doubts, you must contact STACKFORCE for clarifying all usage rights prior to start using that software. Any infringement will be pursued legally.

For further details on usage rights, terms and conditions, commercial and other related information, please refer to the STACKFORCE homepage respective get in contact with STACKFORCE:

| Contact |
| :---- |
STACKFORCE GmbH<BR>
Biengener Str. 3<BR>
79427 Eschbach<BR>
Germany<BR>
Tel.: +49-7634-69960-20 <br>
Fax.: +49-7634-69960-30 <br>
Mail: info@stackforce.de <br>
